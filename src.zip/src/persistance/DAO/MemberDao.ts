import type { Member } from "../Entity/Member.js";

export interface MemberDao {
  insert(member: Member): Promise<boolean>;
  update(member: Member): Promise<boolean>;
  delete(id: number): Promise<boolean>;
  findAll(): Promise<Member[]>;
  findById(id: number): Promise<Member | null>;
}
