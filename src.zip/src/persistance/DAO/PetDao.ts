import type { Pet } from "../Entity/Pet.js";

export interface PetDao {
  insert(pet: Pet): Promise<boolean>;
  update(pet: Pet): Promise<boolean>;
  delete(id: number): Promise<boolean>;
  findAll(): Promise<Pet[]>;
  findById(id: number): Promise<Pet | null>;
  findByMember(memberId: number): Promise<Pet[]>;
}
