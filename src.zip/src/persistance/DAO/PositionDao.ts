import type { Position } from "../Entity/Position.js";

export interface PositionDao {
  insert(position: Position): Promise<boolean>;
  update(position: Position): Promise<boolean>;
  delete(id: number): Promise<boolean>;
  findAll(): Promise<Position[]>;
  findById(id: number): Promise<Position | null>;
}
